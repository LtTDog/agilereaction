$(".button-collapse").sideNav();

$(document).ready(function(){
      $('.slider').slider();
    });